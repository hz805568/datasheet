/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2001 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* File Name   : Spmc75_typedef.h										     */	
/* Description : data structure and variable type define 				     */
/* Processor   : SPMC75X series											     */	
/* Author      : Chih ming Huang										     */
/* Tools	   : u'nSP IDE tools v1.18.1A or later version				     */
/* Version     : 1.00 													     */	
/* Security    : Confidential Proprietary 							         */
/* E-Mail      : MaxHuang@sunplus.com.tw								     */
/* ========================================================================= */
#ifndef __SPMC75_TYPEDEF_H
#define __SPMC75_TYPEDEF_H

/*****************************************************************************/
/* Arithematic operation for u'nSP in C-language environment			     */
/*****************************************************************************/
#ifndef __BOOLEAN
	#define __BOOLEAN
	typedef unsigned char	Boolean;
#endif	

#ifndef __CHAR8
	#define __CHAR8
	typedef char	Char8;
#endif /* #ifndef _CHAR8 */

#ifndef _UINT8
	#define __UINT8
	typedef unsigned char	UInt8;
#endif /* #ifndef _UINT8 */	

#ifndef __INT8
	#define __INT8
	typedef signed char		Int8;
#endif /* #ifndef _INT8 */

#ifndef __SHORT16
	#define __SHORT16
	typedef short			Short16;
#endif /* #ifndef _SHORT16 */

#ifndef __INT16
	#define __INT16
	typedef int				Int16;
#endif /* #ifndef _INT16 */

#ifndef __UINT16
	#define __UINT16
	typedef unsigned int	UInt16;
#endif /* #ifndef _UINT16 */

#ifndef __INT32
	#define __INT32
	typedef long			Int32;
#endif /* #ifndef _INT32 */

#ifndef __UINT32
	#define __UINT32
	typedef unsigned long	UInt32;
#endif /* #ifndef _UINT32 */

#ifndef __FLOAT32
	#define __FLOAT32
	typedef float			Float32;
#endif /* #ifndef _FLOAT32 */

#ifndef __FLOAT64
	#define __FLOAT64
	typedef double			Float64;
#endif /* #ifndef _FLOAT64 */

#define HI_BYTE(n)			(UInt16)((n >> 8) & 0xFF)	      /* n : 16 bits */
#define LO_BYTE(n)			(UInt16)(n & 0xFF)		 	      /* n : 16 bits */
#define BYTE2WORD(hi, lo)	(UInt16)((hi << 8) | lo)	

#define HI_WORD(n)			(UInt16)((n >> 16) & 0x0FFFF)	  /* n : 32 bits */
#define LO_WORD(n)			(UInt16)(n & 0x0FFFF)			  /* n : 32 bits */
#define WORD2LONG(hi, lo)	(UInt32)(((UInt32)hi << 16) | lo)	

/*****************************************************************************/
/* Derived Data Structure                                     			     */
/*****************************************************************************/
typedef union
{
    UInt16		WordCode;
    struct
    {
        UInt16  _byte0      : 8;						    /* LSB byte code */
        UInt16  _byte1      : 8;						    /* MSB byte code */
    } ByteCode;
} UWORD;

typedef union
{
    Int16        WordCode;
    struct
    {
        UInt16	_byte0      : 8;						    /* LSB byte code */
        Int16	_byte1      : 8;						    /* MSB byte code */
    } ByteCode;
} SWORD;

typedef union
{
    UInt32		LongCode;
    struct
    {
        UInt16  _word0      : 16;						    /* LSB word code */
        UInt16  _word1		: 16;						    /* MSB word code */
    } WordCode;
    struct
    {
        UInt16  _byte0      : 8;						      /* bit 7  ~  0 */
        UInt16  _byte1      : 8;						      /* bit 15 ~  8 */
        UInt16  _byte2      : 8;						      /* bit 23 ~ 16 */	
        UInt16  _byte3      : 8;						      /* bit 31 ~ 24 */
    } ByteCode;
} ULONG;

typedef union
{
    Int32    LongCode;
    struct
    {
        UInt16  _word0      : 16;						    /* LSB word code */
        Int16   _word1      : 16;						    /* MSB word code */
    } WordCode;
    struct
    {
        UInt16  _byte0      : 8;						      /* bit  7 ~  0 */
        UInt16  _byte1      : 8;						      /* bit 15 ~  8 */
        UInt16  _byte2      : 8;						      /* bit 23 ~ 16 */ 
        Int16   _byte3      : 8;						      /* bit 31 ~ 24 */
    } ByteCode;
} SLONG;

#define BYTE0           ByteCode._byte0
#define BYTE1           ByteCode._byte1
#define BYTE2           ByteCode._byte2
#define BYTE3           ByteCode._byte3
#define WORD0           WordCode._word0
#define WORD1           WordCode._word1

#define ByteCode(x)		x._byte1 << 8 + x._byte0
#define WordCode(x)		(x._byte3 << 24 + x._byte2 << 16) + \
				 		(x._byte1 << 8 + x._byte0)

#define Byte0(x)		x._byte0			
#define Byte1(x)		x._byte1			
#define Byte2(x)		x._byte2			
#define Byte3(x)		x._byte3			

#endif /* #ifndef __SPMC75_TYPEDEF_H */