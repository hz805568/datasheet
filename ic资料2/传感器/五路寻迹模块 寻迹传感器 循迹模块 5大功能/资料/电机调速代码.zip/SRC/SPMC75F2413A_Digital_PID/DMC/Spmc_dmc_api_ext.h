/* ========================================================================= */
/* File Name   : Spmc_dmc_api_ext.h										     */	
/* Description : External API function prototype for DMC toolkit		     */
/* Processor   : SPMC701FM0A											     */	
/* Author      : Chih ming Huang										     */
/* Date        : August 2004											     */
/* Tools	   : u'nSP IDE tools v1.15.6 								     */
/* Version     : 1.00 													     */	
/* Security    : Confidential Proprietary 							         */
/* E-Mail      : MaxHuang@sunplus.com.tw								     */
/* ========================================================================= */
#ifndef __SPMC_DMC_API_EXT_H
#define __SPMC_DMC_API_EXT_H


/*****************************************************************************/
/* External function callable prototype declaration							 */
/*****************************************************************************/
extern void SPMC_DMC_Save_SpdNow(UInt16, Int16);
extern void SPMC_DMC_Save_Vbus(UInt16);
extern void SPMC_DMC_Save_LineFreq(UInt16);
extern void SPMC_DMC_Save_Thermal(UInt16, Int16);		
extern void SPMC_DMC_Save_Aux(UInt16, UInt16);

extern UInt16 SPMC_DMC_Load_MotorSig(UInt16);
extern Int16  SPMC_DMC_Load_SpdCmd(UInt16);
extern UInt16 SPMC_DMC_Load_SpdSlope(UInt16);
extern UInt16 SPMC_DMC_Load_SpdKp(UInt16);
extern UInt16 SPMC_DMC_Load_SpdKi(UInt16);
extern UInt16 SPMC_DMC_Load_Aux(UInt16);

#endif /* #ifndef __SPMC_DMC_API_EXT_H */


