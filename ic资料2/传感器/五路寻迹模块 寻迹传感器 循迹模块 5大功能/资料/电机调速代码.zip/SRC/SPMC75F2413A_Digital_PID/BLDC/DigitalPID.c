
/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2004 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* 																			 */
/* ========================================================================= */
/* Project Name  : SPMC75F2413A_Digital_PID	            					 */
/* File Name     : DigitalPID.c												 */
/* Description   : Digital PID Speed Controller for Motor Drive Applications */
/*                 Using SPMC75F2413A                              		     */
/* Processor     : SPMC75F2413A											     */
/* Tools	     : u'nSP IDE tools v1.18.1A or later version				 */
/* ========================================================================= */
/* Revision																	 */
/* ========================================================================= */
/* Version       :  1.00   													 */
/* Date			 :	2005.9.1												 */
/* Modified by   :	����������ļ�ͷ�����µ�ͷ�ļ�							 */
/* Description	 :												    		 */
/* ========================================================================= */

typedef struct PID
{
	int  SetPoint; 			//  �趨Ŀ�� Desired Value
	long SumError;			//	����ۼ� 
		
	double  Proportion;     //  �������� Proportional Const
	double  Integral;       //  ���ֳ��� Integral Const
	double  Derivative;     //  ΢�ֳ��� Derivative Const

	int LastError;         	//  Error[-1]
	int PrevError;          //  Error[-2]

} PID;

static PID	 sPID;
static PID	 *sptr = &sPID;
//============================================================= 
// ----Function: IncPIDInit() 
// ------Syntax: void IncPIDInit(void);
// -Description: Initialization PID parameter.
// -------Notes: 
// --parameters: none
// -----returns: none
//=============================================================
void PIDInit(void)
{
    sptr->LastError  = 0;			//Error[-1]
    sptr->PrevError  = 0;			//Error[-2]
	sptr->Proportion = 0;			//�������� Proportional Const
    sptr->Integral   = 0;			//���ֳ��� Integral Const
    sptr->Derivative = 0;			//΢�ֳ��� Derivative Const
    sptr->SetPoint   = 0;
	sptr->SumError   = 0;
}

//============================================================= 
// ----Function: IncPIDSetPoint() 
// ------Syntax: void IncPIDSetPoint(unsigned int setpoint);
// -Description: Set PID Desired Value
// -------Notes: 
// --parameters: Desired Value
// -----returns: none
//=============================================================
void PIDSetPoint(int setpoint)
{	sptr->SetPoint = setpoint;	}

int PIDGetSetpoint(void)
{	return(sptr->SetPoint);	}
//============================================================= 
// ----Function: IncPIDKp() 
// ------Syntax: void IncPIDKp(double dKp);
// -Description: Set PID Proportion coefficient
// -------Notes: 
// --parameters: Proportion Const
// -----returns: none
//=============================================================
void PIDSetKp(double dKpp)
{	sptr->Proportion = dKpp;	}
//===================================//
// Get Proportion
//===================================//
double PIDGetKp(void)
{	return(sptr->Proportion);	}
//============================================================= 
// ----Function: IncPIDKi() 
// ------Syntax: void IncPIDKi(double dKi);
// -Description: Set PID Integral coefficient
// -------Notes: 
// --parameters: Integral Const
// -----returns: none
//=============================================================
void PIDSetKi(double dKii)
{	sptr->Integral = dKii;	}
//===================================//
// Get Integral
//===================================//
double PIDGetKi(void)
{	return(sptr->Integral);	}
//============================================================= 
// ----Function: IncPIDKd() 
// ------Syntax: void IncPIDKd(double dKd);
// -Description: Set PID Derivative coefficient
// -------Notes: 
// --parameters: Derivative Const
// -----returns: none
//=============================================================
void PIDSetKd(double dKdd)
{	sptr->Derivative = dKdd;	}
//===================================//
// Get Derivative
//===================================//
double PIDGetKd(void)
{	return(sptr->Derivative);	}
//============================================================= 
// ----Function: IncPIDCalc() 
// ------Syntax: int IncPIDCalc(unsigned int NextPoint);
// -Description: Increment Digital PID calculate
// -------Notes: Basic Increment Digital PID
// --parameters: Next Point
// -----returns: increase controls parameter
//=============================================================
int IncPIDCalc(int NextPoint)
{
	register int iError, iIncpid;

	iError = sptr->SetPoint - NextPoint;

	iIncpid = sptr->Proportion * iError				//E[0]
            - sptr->Integral   * sptr->LastError	//E[-1]
            + sptr->Derivative * sptr->PrevError;	//E[-2]

	sptr->PrevError = sptr->LastError;
	sptr->LastError = iError;

	return(iIncpid);
}

//============================================================= 
// ----Function: LocPIDCalc() 
// ------Syntax: unsigned int locPIDCalc(unsigned int NextPoint);
// -Description: Location Digital PID calculate
// -------Notes: Basic Location Digital PID
// --parameters: Next Point
// -----returns: Location controls parameter
//=============================================================
unsigned int LocPIDCalc(int NextPoint)
{
    register int  iError,dError;
	
	iError = sptr->SetPoint - NextPoint;      	// ƫ��
	sptr->SumError += iError;					// ����
	dError = iError - sptr->LastError; 			// ��ǰ΢��
	sptr->LastError = iError;

	return(sptr->Proportion * iError           	// ������
           + sptr->Integral * sptr->SumError 	// ������
           + sptr->Derivative * dError);
}

//=============================================//
//	*END*
//=============================================//