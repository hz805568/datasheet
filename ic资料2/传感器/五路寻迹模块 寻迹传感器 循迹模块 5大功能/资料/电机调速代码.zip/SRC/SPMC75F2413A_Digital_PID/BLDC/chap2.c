
/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2004 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* 																			 */
/* ========================================================================= */
/* Project Name  : SPMC75F2413A_Digital_PID	            					 */
/* File Name     : chap2.c													 */
/* Description   : ϵͳ����													 */
/*                					                              		     */
/* Processor     : SPMC75F2413A											     */
/* Tools	     : u'nSP IDE tools v1.18.1A or later version				 */
/* ========================================================================= */
/* Revision																	 */
/* ========================================================================= */
/* Version       :  1.00   													 */
/* Date			 :	2005.9.1												 */
/* Modified by   :	����������ļ�ͷ�����µ�ͷ�ļ�							 */
/* Description	 :												    		 */
/* ========================================================================= */

//=============================================//
//Include File
//=============================================//
#include	"BLDC.h"

#define		DMC_PID_DEBUG
//=============================================//
//120�ȷ��������ź�PWM���뷽ʽѡ������תѡ��
//=============================================//
//=============================================//
static CONTROLSM sCtrlSM;
static CONTROLSM *sCSptr = &sCtrlSM;
static unsigned int uiFilter[CAPBSIZE]={0};
static unsigned int *ptr = uiFilter;
unsigned int uiGoalvalue=0;
//=============================================//
static void Speedcalc(void);
static void IPM_Charge(void);
static void IPM_Trigger_Off(void);
static void IPM_Trigger_PB120HalfPWM(unsigned int position);
/*=================================================================*/
/*BLDC ����
/*=================================================================*/
#define		limpoint		MAXPWM/2
#define		inclength		1
static long summation = 0;

int abs(int number)
{	return(number>0? number:(-number));	}

void BLDC_Motor_Actiyator(void)
{
	static unsigned int count = 0;
	unsigned int uiSpeed = 0;
#ifdef	DMC_PID_DEBUG
	static unsigned int uiKp = 0;
	double dKp;
#endif

	if(!sCSptr->B._charge && sCSptr->B._workflag)
	{
		IPM_Charge();						//IPM���
		count ++;
		if(count > 100)						//���ʱ��100*��ʱ����
		{
			IPM_Trigger_Off();
			sCSptr->B._slowflag = 1;
			sCSptr->B._charge = 1;
			count = 0;
		}	
	}
	else if(sCSptr->B._startup)
	{
		uiSpeed = 1875000L/(summation>>SHIFTDIV);		//�����ٶ�
		
		if(uiGoalvalue < 400)	uiGoalvalue += inclength;
		else	uiGoalvalue += IncPIDCalc(uiSpeed);	//PID����
														//PWM�޷�
		if(uiGoalvalue > MAXPWM)	uiGoalvalue = MAXPWM;
		if(uiGoalvalue < MINPWM)	uiGoalvalue = MINPWM;
		P_TMR3_TGRA->W = uiGoalvalue;
		P_TMR_LDOK->W  = CW_TMR_LDOK0;
	}
#ifdef	DMC_PID_DEBUG
	if(uiKp != SPMC_DMC_Load_SpdKp(1))
	{
		uiKp = SPMC_DMC_Load_SpdKp(1);
		dKp = uiKp/1000.0;
		PIDSetKp(2.45*dKp);
		PIDSetKi(3.50*dKp);
		PIDSetKd(1.25*dKp);
		SPMC_DMC_Save_Aux(2, uiKp);
	}	
#endif												 	//DMC��������
	PIDSetPoint(SPMC_DMC_Load_SpdCmd(1));   	      	//�����ٶ�
	SPMC_DMC_Save_SpdNow(1, uiSpeed);                	//���͵�ǰ�ٶ�
	SPMC_DMC_Save_Aux(0, uiGoalvalue);               	//��ǰP_TMR3_TGRAֵ
	SPMC_DMC_Save_Aux(1, abs(PIDGetSetpoint() - uiSpeed));//��ǰת��ƫ��
}

/*=================================================================*/
/*BLDC ����
/*=================================================================*/
void BLDC_Motor_Startup(void)
{
	if(sCSptr->B._slowflag)
	{
		sCtrlSM.B._startup = 0;
		if(uiGoalvalue < limpoint)
		{
			uiGoalvalue += 5;
			P_TMR3_TGRA->W = uiGoalvalue;
			P_TMR_LDOK->W  = CW_TMR_LDOK0;
		}
		else
		{
			uiGoalvalue = MINPWM;
			P_TMR3_TGRA->W = uiGoalvalue;
			P_TMR_LDOK->W  = CW_TMR_LDOK0;
		}
		IPM_Trigger_PB120HalfPWM(P_POS0_DectData->W);
	}
	else IPM_Trigger_Off();
}

/*=================================================================*/
/*BLDC ������ת
/*=================================================================*/
void BLDC_Motor_Normalrun(void)
{
	P_TMR0_Status->B.PDCIF = 1;
	if(sCSptr->B._slowflag)
	{
		sCSptr->B._startup = 1;
		Speedcalc();				//�˲�
		IPM_Trigger_PB120HalfPWM(P_POS0_DectData->W);
	}
	else IPM_Trigger_Off();
}

/*=================================================================*/
/*
/*=================================================================*/
#define		RADIX		(((24.0E+6)*60) / (64*6*2))

#define		MAXRPM		(unsigned int)((long)RADIX/5000)	//187
#define		MINRPM		(unsigned int)((long)RADIX/500)		//1875

static void Speedcalc(void)
{
	unsigned int original;

	original = P_TMR0_TGRA->W;
	if(original > 469)			//���ת��������4000rpm��RADIX/4000��
	{
		summation -= *ptr;		//�����˲�
		*ptr = original;
		summation += *ptr;
		if((++ptr) > (uiFilter+CAPBSIZE-1))		ptr = uiFilter;
	}
}

/*=================================================================*/
/*IPM ���
/*=================================================================*/
static void IPM_Charge(void)
{
	P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
						   CW_TMR3_UPWM_Out_HL | CW_TMR3_UOC_Mode1 |	\
						   CW_TMR3_VPWM_Out_HL | CW_TMR3_VOC_Mode1 |	\
						   CW_TMR3_WPWM_Out_HL | CW_TMR3_WOC_Mode1;
}

/*=================================================================*/
/*
/*=================================================================*/
void BLDC_Run_Service(void)
{
	register int i;
	
	MC75_DMC_UART_Service();			//DMC�������

	if(SPMC_DMC_Load_MotorSig(1))		//���������ж�
	{
		P_IOB_Data->B.bit14 = 1;
		sCSptr->B._workflag = 1;
		P_Fault1_Ctrl->B.FTPINE = 1;
	} 
	else
	{									//��λ�Ĵ���
		P_IOB_Data->B.bit14 = 0;
		IPM_Trigger_Off();
		for(i=0;i<CAPBSIZE;i++)	uiFilter[i] = 0;
		BLDC_PID_Init();
	    summation = 0;
		sCSptr->W = 0;
		P_Fault1_Ctrl->B.FTPINE = 0;
	}
}

/*=================================================================*/
/*IPM ���� ������󱣻���������󱣻�
/*=================================================================*/
void IPM_Fault_Protect(void)
{
	if(P_INT_Status->B.FTIF)
	{
		if(P_Fault1_Ctrl->B.OSF)
		{									//��·������󱣻�
			P_IOB_Data->B.bit14  = 0;
			P_Fault1_Release->W  = 0xAA55;
			P_Fault1_Release->W  = 0x55AA;
			P_Fault1_Ctrl->B.OCE = 1;
			P_Fault1_Ctrl->B.FTPINE  = 1;
			P_IOB_Data->B.bit14 = 1;
		}
		
		if(P_Fault1_Ctrl->B.FTPINIF)
		{									//�������뱣��
			P_IOB_Data->B.bit14  = 0;
			P_Fault1_Release->W  = 0x55AA;
			P_Fault1_Release->W  = 0xAA55;
			P_Fault1_Ctrl->B.OCE = 1;
			P_Fault1_Ctrl->B.FTPINE  = 1;
			P_IOB_Data->B.bit14 = 1;
		}
	}
}
/*=================================================================*/
/*IPM �ض�
/*=================================================================*/
static void IPM_Trigger_Off(void)
{
	P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
						   CW_TMR3_UPWM_Out_HL | CW_TMR3_UOC_Mode0 |	\
						   CW_TMR3_VPWM_Out_HL | CW_TMR3_VOC_Mode0 |	\
						   CW_TMR3_WPWM_Out_HL | CW_TMR3_WOC_Mode0;
}

//=============================================//
//120 Degree Wave Trigger For BLDC etc.
//BLDC��תʱ,120�Ⱥ��PWM�����źŲ���
//6,4,5,1,3,2
//=============================================//
static void IPM_Trigger_PB120HalfPWM(unsigned int position)
{
	switch(position&0x07)
	{
		case(6):	//V1,V2
			P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
								   CW_TMR3_UPWM_Out_HL  | CW_TMR3_UOC_Mode2 |\
								   CW_TMR3_VPWM_Out_HL  | CW_TMR3_VOC_Mode0 |\
								   CW_TMR3_WPWM_Out_PWM | CW_TMR3_WOC_Mode1;
			break;
					
		case(4):	//V2,V3
			P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
								   CW_TMR3_UPWM_Out_HL  | CW_TMR3_UOC_Mode0 |\
								   CW_TMR3_VPWM_Out_PWM | CW_TMR3_VOC_Mode2 |\
								   CW_TMR3_WPWM_Out_HL  | CW_TMR3_WOC_Mode1;
			break;
				
		case(5):	//V3,V4
			P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
								   CW_TMR3_UPWM_Out_PWM | CW_TMR3_UOC_Mode1 |\
								   CW_TMR3_VPWM_Out_HL  | CW_TMR3_VOC_Mode2 |\
								   CW_TMR3_WPWM_Out_HL  | CW_TMR3_WOC_Mode0;
			break;
				
		case(1):	//V4,V5
			P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
								   CW_TMR3_UPWM_Out_HL  | CW_TMR3_UOC_Mode1 |\
								   CW_TMR3_VPWM_Out_HL  | CW_TMR3_VOC_Mode0 |\
								   CW_TMR3_WPWM_Out_PWM | CW_TMR3_WOC_Mode2;
			break;
			
		case(3):	//V5,V6
			P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
								   CW_TMR3_UPWM_Out_HL  | CW_TMR3_UOC_Mode0 |\
								   CW_TMR3_VPWM_Out_PWM | CW_TMR3_VOC_Mode1 |\
								   CW_TMR3_WPWM_Out_HL  | CW_TMR3_WOC_Mode2;
			break;

		case(2):	//V6,V1
			P_TMR3_OutputCtrl->W = CW_TMR3_POLP_Active_High	|	\
								   CW_TMR3_UPWM_Out_PWM | CW_TMR3_UOC_Mode2 |\
								   CW_TMR3_VPWM_Out_HL  | CW_TMR3_VOC_Mode1 |\
								   CW_TMR3_WPWM_Out_HL  | CW_TMR3_WOC_Mode0;
			break;

		default:
			IPM_Trigger_Off();
			break;
	}
}
/*=================================================================*/
/*	*END*
/*=================================================================*/