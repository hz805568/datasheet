
/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2004 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* 																			 */
/* ========================================================================= */
/* Project Name  : SPMC75F2413A_Digital_PID	            					 */
/* File Name     : Initial.c												 */
/* Description   : ϵͳ��ʼ��												 */
/*                					                              		     */
/* Processor     : SPMC75F2413A											     */
/* Tools	     : u'nSP IDE tools v1.18.1A or later version				 */
/* ========================================================================= */
/* Revision																	 */
/* ========================================================================= */
/* Version       :  1.00   													 */
/* Date			 :	2005.9.1												 */
/* Modified by   :	����������ļ�ͷ�����µ�ͷ�ļ�							 */
/* Description	 :												    		 */
/* ========================================================================= */

//=============================================//
//Include File
//=============================================//
#include	"BLDC.h"

//=============================================//
//=============================================//
//PDC Initial and SPD CAP Initial etc.
//=============================================//
static void Timer_PDC_Init(void)
{
	P_IOB_Attrib->B.bit8 = 0;
	P_IOB_Dir->B.bit8    = 0;
	P_IOB_Buffer->B.bit8 = 0;
	
	P_IOB_Attrib->B.bit9 = 0;
	P_IOB_Dir->B.bit9 	 = 0;
	P_IOB_Buffer->B.bit9 = 0;
	
	P_IOB_Attrib->B.bit10 = 0;
	P_IOB_Dir->B.bit10 	  = 0;
	P_IOB_Buffer->B.bit10 = 0;

	P_POS0_DectCtrl->W = CW_TMR0_PDCR_SPLCK_FCKdiv32 |
						 CW_TMR0_PDCR_SPLMOD_Mode2   |
						 CW_TMR0_PDCR_PDEN | 100;

	P_POS0_DectCtrl->B.SPLCNT = 10;

/* ------------------------------- */	
	P_TMR0_Ctrl->W = CW_TMR0_MODE_Normal  | CW_TMR0_CLEGS_Rising |
					 CW_TMR0_CKEGS_Rising | CW_TMR0_CCLS_PDR 	 |
					 CW_TMR0_SPCK_FCKdiv8 | CW_TMR0_TMRPS_FCKdiv64;
	
	P_TMR0_INT->B.TCVIE = CB_TMR0_TCVIE_Enable;
/* ------------------------------- */
	P_TMR0_IOCtrl->B.IOAMODE = CB_TMR0_IOAMOD_Capture_PDR;
	P_TMR0_INT->B.PDCIE = CB_TMR0_PDCIE_Enable;
	
	P_TMR_Start->B.TMR0ST = CB_TMR_TMR0ST_Start;
}

//=============================================//
//120/180 Degree Wave Trigger For BLDC etc.
//=============================================//
static void Timer_BLDC_Init(void)
{
	P_TPWM_Write->W = CW_TWCR_TMR3WE;
	
	P_TMR3_Ctrl->W = CW_TMR3_MODE_PWM_Edge | 
					 CW_TMR3_TMRPS_FCKdiv1 |
					 CW_TMR3_CKEGS_Rising  |
					 CW_TMR3_CCLS_TPR;

	P_TMR3_TPR->W  = CYCPWM;
	P_TMR3_TGRA->W = MINPWM;
	P_TMR_LDOK->W  = CW_TMR_LDOK0;

//	P_TMR3_INT->B.TPRIE = CB_TMR3_TPRIE_Enable;
	
	P_IOB_SPE->W = CW_IOB_W1N_SFR_EN | CW_IOB_V1N_SFR_EN |	\
				   CW_IOB_U1N_SFR_EN | CW_IOB_W1_SFR_EN  |	\
				   CW_IOB_V1_SFR_EN  | CW_IOB_U1_SFR_EN;
	
	P_TMR3_IOCtrl->W = CW_TMR3_IOAMOD_Output_10 |	\
					   CW_TMR3_IOBMOD_Output_10 |	\
					   CW_TMR3_IOCMOD_Output_10;
	
	P_TMR3_OutputCtrl->W = 0;			   
	P_TMR3_OutputCtrl->B.POLP = CB_TMR3_POLP_Active_High;

	P_TMR_Output->W = CW_TMR_TMR3AOE_Enable | CW_TMR_TMR3BOE_Enable |	\
					  CW_TMR_TMR3COE_Enable | CW_TMR_TMR3DOE_Enable |	\
					  CW_TMR_TMR3EOE_Enable | CW_TMR_TMR3FOE_Enable;

	P_TMR_Start->B.TMR3ST = CB_TMR_TMR3ST_Start;	
}

//=============================================//
//Fault input protect function
//=============================================//
static void Timer_Fault_Init(void)
{
	P_Fault1_Release->W = 0xAA55;
	P_Fault1_Release->W = 0x55AA;
	P_Fault1_Ctrl->W = CW_TMR3_FCR_OCE  | 	\
					   CW_TMR3_FCR_OCIE |	\
				 	   CW_TMR3_FCR_OCLS_High;

	P_Fault1_Release->W = 0x55AA;
	P_Fault1_Release->W = 0xAA55;
	P_Fault1_Ctrl->B.FTCNT = 10;
	
	P_Fault1_Ctrl->W |= CW_TMR3_FCR_FTPINIF | 	\
						CW_TMR3_FCR_FTPINIE |	\
						CW_TMR3_FCR_FTPINE;
						
	P_IOB_Attrib->B.bit6 = 0;
	P_IOB_Dir->B.bit6 	 = 0;
	P_IOB_Data->B.bit6 	 = 1;
	P_IOB_SPE->W |= CW_IOB_FTIN1_SFR_EN;
}

//=============================================//
//
//=============================================//
static void Spmc75_CMT_Init(void)
{
	P_CMT_Start->W = 0x0000;

	P_CMT_Ctrl->W = 0x0000;
	P_CMT_Ctrl->B.CKA 	= CB_CKA_FCK_16;
	P_CMT_Ctrl->B.CM0IE = CB_CMT0_INT_EN;
	P_CMT_Ctrl->B.CM0IF = CB_CLEAR_CM0IF;
	
	P_CMT0_TPR->W = 2929;//512Hz@24M/16

/*	P_CMT_Ctrl->B.CKB = CB_CKB_FCK_1;
	P_CMT_Ctrl->B.CM1IE = CB_CMT1_INT_EN;
	P_CMT_Ctrl->B.CM1IF = CB_CLEAR_CM1IF;
	
	P_CMT1_TPR->W = 6000;*/
	
	P_CMT_Start->B.ST0 = CB_CMT0_Start;	
//	P_CMT_Start->B.ST1 = CB_CMT1_Start;
}

//=============================================//
//
//=============================================//
extern unsigned int uiGoalvalue;
void BLDC_PID_Init(void)
{
	uiGoalvalue = MINPWM;
	PIDInit();
	PIDSetPoint(1000);
	PIDSetKp(KPP);
	PIDSetKi(KPI);
	PIDSetKd(KPD);
}

//=============================================//
//
//=============================================//
void Spmc75_System_Init(void)
{
	Disable_FIQ_IRQ();
	P_IOB_Attrib->B.bit14 	= 1;
	P_IOB_Dir->B.bit14 		= 1;
	P_IOB_Buffer->B.bit14	= 1;
	P_IOB_Data->B.bit14 	= 0;
	
	BLDC_PID_Init();
	Spmc75_CMT_Init();
	Timer_BLDC_Init();
	Timer_PDC_Init();
	MC75_DMC_UART_Setup(9600);	
	Timer_Fault_Init();	
	INT_FIQ_IRQ();
}
//=============================================//
//	*END*
//=============================================//