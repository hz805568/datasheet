
/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2004 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* 																			 */
/* ========================================================================= */
/* Project Name  : SPMC75F2413A_Digital_PID	            					 */
/* File Name     : main.c													 */
/* Description   : 3-Phase BLDC Motor Control with Hall Sensor				 */
/*                 				                                		     */
/* Processor     : SPMC75F2413A											     */
/* Tools	     : u'nSP IDE tools v1.18.1A or later version				 */
/* ========================================================================= */
/* Revision																	 */
/* ========================================================================= */
/* Version       :  1.00   													 */
/* Date			 :	2005.9.1												 */
/* Modified by   :	����������ļ�ͷ�����µ�ͷ�ļ�							 */
/* Description	 :												    		 */
/* ========================================================================= */

#include	"Spmc75_BLDC.h"
/*=============================================*/
/* main program for test
/*=============================================*/
main()
{
	P_IOA_SPE->W = 0x0000;
	P_IOB_SPE->W = 0x0000;
	P_IOC_SPE->W = 0x0000;
	
	P_IOB_Attrib->W = 0xffff;
	P_IOB_Dir->W 	= 0xffff;
	P_IOB_Buffer->W = 0xffff;
	P_IOB_Data->W 	= 0x0000;
	
	Spmc75_System_Init();

	while(1)
	{
		BLDC_Run_Service();
		NOP();
		NOP();
		NOP();
	}	
	
}